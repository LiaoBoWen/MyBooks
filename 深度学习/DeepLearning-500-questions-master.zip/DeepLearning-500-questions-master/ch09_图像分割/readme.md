###########################################################

### 深度学习500问-第九章 图像分割

**负责人（排名不分先后）：**  
电子科大研究生-孙洪卫（wechat：sunhwee，email：hwsun@std.uestc.edu.cn）  
电子科大研究生-张越（wechat：tianyuzy）  
华南理工研究生-黄钦建（wechat：HQJ199508212176，email：csqjhuang@mail.scut.edu.cn）  
中国农业科学院-杨国峰（wechat：tectal，email：yangguofeng@caas.cn） 

**贡献者（排名不分先后）：**  
内容贡献者可自加信息

###########################################################
